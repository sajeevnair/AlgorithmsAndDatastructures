#include <iostream>
#include <fstream>

using namespace::std;


void printArray(int*, int);
void printArray(char*, int);
void swap(int& , int&);
void swap(char&, char&);